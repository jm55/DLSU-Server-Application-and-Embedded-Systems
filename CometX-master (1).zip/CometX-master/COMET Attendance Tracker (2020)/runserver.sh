sudo chmod 777 /dev/ttyACM0
sudo python3 manage.py runserver 0.0.0.0:8000
